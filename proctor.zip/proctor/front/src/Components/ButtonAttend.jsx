import React, { useState } from 'react';
import DialogSystem from './DialogSystem'; // Import the Dialog component

function ButtonAttend() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleOpenDialog = () => {
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    console.log("handleCloseDialog called"); // Debugging statement
    setIsDialogOpen(false);
  };

  return (
    <div>
      <div className="fixed top-4 right-4">
        <button
          onClick={handleOpenDialog}
          className="bg-blue-500 text-white font-bold py-2 px-4 rounded shadow hover:bg-blue-700 transition duration-300"
        >
          ButtonAttend
        </button>
      </div>
      <DialogSystem isOpen={isDialogOpen} onClose={handleCloseDialog} />
    </div>
  );
}

export default ButtonAttend;
