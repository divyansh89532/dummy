import React, { useState } from 'react';
import ProctoringWithWindowWatcher from './ProctoringSystem';
import ExamPage from './ExamPage';

const ExamPageWithProctoring = () => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isExamActive, setIsExamActive] = useState(true);

  return (
    <div className="relative">
      {/* Exam Page */}
      <ExamPage />

      {/* Proctoring System */}
      <ProctoringWithWindowWatcher 
        setIsExamActive={setIsExamActive} 
        setIsFullscreen={setIsFullscreen} 
        isExamActive={isExamActive} 
        isFullscreen={isFullscreen} 
      />
    </div>
  );
};

export default ExamPageWithProctoring;
