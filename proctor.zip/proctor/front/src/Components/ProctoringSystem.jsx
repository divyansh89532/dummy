import React, { useState, useEffect, useRef } from 'react';
import * as sdk from 'microsoft-cognitiveservices-speech-sdk';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const SPEECH_KEY = import.meta.env.VITE_SPEECH_KEY;
const SPEECH_REGION = import.meta.env.VITE_SPEECH_REGION;

function ProctoringWithWindowWatcher({ setIsExamActive, setIsFullscreen, isExamActive, isFullscreen }) {
  const [noiseCount, setNoiseCount] = useState(0);
  const [faceCount, setFaceCount] = useState(null);
  const [exitCount, setExitCount] = useState(0);
  const [deviationCount, setDeviationCount] = useState(0);
  const [initialTitle, setInitialTitle] = useState('');
  const [currentTitle, setCurrentTitle] = useState('');
  const [deviations, setDeviations] = useState([]);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const speechConfig = useRef(null);
  const audioConfig = useRef(null);
  const recognizer = useRef(null);

  useEffect(() => {
    // Initialize Speech Recognizer for noise detection
    speechConfig.current = sdk.SpeechConfig.fromSubscription(SPEECH_KEY, SPEECH_REGION);
    speechConfig.current.speechRecognitionLanguage = 'en-US';

    audioConfig.current = sdk.AudioConfig.fromDefaultMicrophoneInput();
    recognizer.current = new sdk.SpeechRecognizer(speechConfig.current, audioConfig.current);

    recognizer.current.recognizing = (s, e) => {
      if (e.result.reason === sdk.ResultReason.RecognizingSpeech) {
        toast.error('Noise detected', {
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
        setNoiseCount((prevCount) => prevCount + 1);
      }
    };

    recognizer.current.startContinuousRecognitionAsync(() => {
      console.log('Speech recognition started.');
    });

    // Access the user's camera
    navigator.mediaDevices.getUserMedia({ video: true })
      .then((stream) => {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      })
      .catch((err) => {
        console.error('Error accessing camera:', err);
        toast.error('Camera access is required for taking this exam');
      });

    const interval = setInterval(() => {
      captureAndCheckImage();
    }, 30000);

    return () => {
      recognizer.current.stopContinuousRecognitionAsync(() => {});
      clearInterval(interval);
    };
  }, []);

  const captureAndCheckImage = async () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(async (blob) => {
      const formData = new FormData();
      formData.append('image', blob, 'snapshot.jpg');

      try {
        const response = await fetch('http://localhost:8000/proctoring/detect-faces', {
          method: 'POST',
          body: formData,
        });

        const data = await response.json();
        setFaceCount(data.face_count);

        if (data.face_count > 1) {
          toast.error('Multiple faces detected!', { autoClose: 5000 });
        } else if (data.face_count < 1) {
          toast.error('No face detected!', { autoClose: 5000 });
        }
      } catch (error) {
        console.error('Error:', error);
      }
    }, 'image/jpeg');
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      axios.get('http://localhost:8000/window_status')
        .then(response => {
          const data = response.data;
          setInitialTitle(data.initial_window_title);
          setCurrentTitle(data.current_window_title);
          setDeviationCount(data.deviation_count);
          setDeviations(data.deviations);

          if (data.deviation_count > deviationCount) {
            toast.warn('Tab switched!', { autoClose: 5000 });
          }
        })
        .catch(error => {
          console.error("Error fetching window status!", error);
        });
    }, 1000);

    return () => clearInterval(intervalId);
  }, [deviationCount]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      if (!document.fullscreenElement && isFullscreen) {
        setIsFullscreen(false);
        setExitCount((prevCount) => prevCount + 1);
        setIsExamActive(false);
        toast.warn('Fullscreen exited! Click the button below to resume the exam.');
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [isFullscreen]);

  return (
    <>
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-50">
        <video ref={videoRef} className="absolute bottom-10 left-10 w-36 h-auto z-50 rounded-lg shadow-lg" />
      </div>
      <canvas ref={canvasRef} className="hidden" />
      <ToastContainer position="top-right" autoClose={5000} hideProgressBar={false} closeOnClick pauseOnHover draggable />
    </>
  );
}

export default ProctoringWithWindowWatcher;
