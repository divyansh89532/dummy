import React from 'react';

const ExamPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-blue-600 text-white p-4 text-center">
        <h1 className="text-xl font-bold">Exam Platform</h1>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto p-6">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Objective Questions</h2>

          <div className="mb-6">
            <h3 className="text-lg font-medium">1. What is the capital of France?</h3>
            <div className="mt-2">
              <label className="block">
                <input type="radio" name="q1" value="a" className="mr-2" />
                A) Berlin
              </label>
              <label className="block">
                <input type="radio" name="q1" value="b" className="mr-2" />
                B) Madrid
              </label>
              <label className="block">
                <input type="radio" name="q1" value="c" className="mr-2" />
                C) Paris
              </label>
              <label className="block">
                <input type="radio" name="q1" value="d" className="mr-2" />
                D) Rome
              </label>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-medium">2. Which of the following is a prime number?</h3>
            <div className="mt-2">
              <label className="block">
                <input type="radio" name="q2" value="a" className="mr-2" />
                A) 4
              </label>
              <label className="block">
                <input type="radio" name="q2" value="b" className="mr-2" />
                B) 6
              </label>
              <label className="block">
                <input type="radio" name="q2" value="c" className="mr-2" />
                C) 9
              </label>
              <label className="block">
                <input type="radio" name="q2" value="d" className="mr-2" />
                D) 7
              </label>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Descriptive Questions</h2>

          <div className="mb-6">
            <h3 className="text-lg font-medium">1. Explain the process of photosynthesis.</h3>
            <textarea
              name="q3"
              rows="5"
              className="w-full border border-gray-300 p-2 mt-2"
              placeholder="Write your answer here..."
            ></textarea>
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-medium">2. Describe your experience with programming.</h3>
            <textarea
              name="q4"
              rows="5"
              className="w-full border border-gray-300 p-2 mt-2"
              placeholder="Write your answer here..."
            ></textarea>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-blue-600 text-white p-4 text-center">
        <p>&copy; 2024 Exam Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default ExamPage;
