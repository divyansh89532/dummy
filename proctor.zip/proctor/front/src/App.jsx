import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ProctoringWithWindowWatcher from './Components/ProctoringSystem'
import PermissionsCheck from './Components/PermissionCheck'
import ExamPage from './Components/ExamPage';

import ButtonAttend from './Components/ButtonAttend';
import { useState } from 'react';
import Register from './Components/Register';
import ExamPageWithProctoring from './Components/ExamPageWithProctoring';
function App() {

  const [isFullscreen , setIsFullscreen] = useState(false);
  const [isExamActive , setIsExamActive] = useState(false);

  return (
   <div>
      <Router>
        <Routes>
          <Route path="/test" element={<PermissionsCheck setIsExamActive = {setIsExamActive} setIsFullscreen = {setIsFullscreen}/>} />
          {/* <Route path="/proctoring" element={<ProctoringWithWindowWatcher isExamActive = {isExamActive} isFullscreen = {isFullscreen} setIsExamActive = {setIsExamActive} setIsFullscreen = {setIsFullscreen}/>} /> */}
          <Route path='/' element={<ButtonAttend/>}></Route>
          {/* <Route path='/test_window' element={<Home/>}></Route> */}
          <Route path='/register' element={<Register/>}></Route>
          <Route path='/proctoring' element={<ExamPageWithProctoring/>}></Route>
        </Routes>
    </Router>
   </div>
  )
}

export default App
