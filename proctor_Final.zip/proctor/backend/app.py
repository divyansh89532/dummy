from fastapi import FastAPI, File, Form, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from azure.cognitiveservices.vision.face import FaceClient
from msrest.authentication import CognitiveServicesCredentials
from azure.storage.blob import BlobServiceClient
import mysql.connector
import os
import uuid
import requests
import io
from datetime import datetime, timedelta
from dotenv import load_dotenv
from PIL import Image, ImageDraw
import threading
import time
import win32gui
from pydantic import BaseModel
from pymongo import MongoClient

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# Azure Face API credentials
ENDPOINT = os.getenv('AZURE_FACE_API_ENDPOINT')
SUBSCRIPTION_KEY = os.getenv('AZURE_FACE_API_SUBSCRIPTION_KEY')
FACELIST_ID = os.getenv('AZURE_FACE_API_FACELIST_ID')

# Azure Blob Storage credentials
BLOB_CONNECTION_STRING = os.getenv('BLOB_CONNECTION_STRING')
CONTAINER_NAME = os.getenv('CONTAINER_NAME')

# MySQL database credentials
MYSQL_HOST = os.getenv('MYSQL_HOST')
MYSQL_USER = os.getenv('MYSQL_USER')
MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD')
MYSQL_DATABASE = os.getenv('MYSQL_DATABASE')

# MongoDB connection
MONGODB_URI = "mongodb+srv://MeridianEdu:Ed%40%232024@edutechdb.mongocluster.cosmos.azure.com/?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000"
client = MongoClient(MONGODB_URI)
db = client['test']
collection = db['Azure_Face_API']

# Initialize FaceClient
face_client = FaceClient(ENDPOINT, CognitiveServicesCredentials(SUBSCRIPTION_KEY))

# Initialize Azure Blob Storage client
blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)

# Initialize window monitoring variables
initial_window_title = ""
current_window_title = ""
deviations = []
deviation_count = 0

monitoring_thread = None # thread variable for tab switching monitoring 

stop_monitoring_flag = threading.Event()  # for stopping the thread 

def get_active_window_title():
    hwnd = win32gui.GetForegroundWindow()  # Get the handle of the active window
    window_title = win32gui.GetWindowText(hwnd)  # Get the title of the active window
    return window_title

def monitor_window():
    global current_window_title, initial_window_title, deviations, deviation_count
    global stop_monitoring_flag

    if not initial_window_title:
        initial_window_title = get_active_window_title()
        current_window_title = initial_window_title

    while not stop_monitoring_flag.is_set():
        new_title = get_active_window_title()

        if new_title != initial_window_title:
            if new_title != current_window_title:
                deviations.append(new_title)
                deviation_count += 1
                current_window_title = new_title
                if current_window_title == "":
                    current_window_title = "Window switch"
                if initial_window_title == "":
                    initial_window_title = 'Window switch'    
                print(f"Window switch detected! New window: {current_window_title}")
        
        time.sleep(1)

@app.get("/window_status")
def get_window_status():
    return JSONResponse(content={
        "initial_window_title": initial_window_title,
        "current_window_title": current_window_title,
        "deviation_count": deviation_count,
        "deviations": deviations
    })

# Face verification 
@app.post("/verify_face/")
async def verify_face(image: UploadFile = File(...), camera_no: int = Form(...)):
    try:
        # Save the uploaded image
        image_path = f"temp_image_{uuid.uuid4()}.jpg"
        with open(image_path, "wb") as buffer:
            buffer.write(image.file.read())

        # Detect face in the uploaded image
        detected_faces = face_client.face.detect_with_stream(open(image_path, 'rb'))
        if not detected_faces:
            return JSONResponse(status_code=400, content={"message": "No face detected in the image."})

        face_id = detected_faces[0].face_id

        # Match the face with the FaceList
        similar_faces = face_client.face.find_similar(face_id=face_id, face_list_id=FACELIST_ID)
        if similar_faces:
            matched_face_id = similar_faces[0].persisted_face_id

            # Fetch user details from MongoDB
            user_info = collection.find_one({"persisted_faceid": matched_face_id})

            if user_info:
                current_time = datetime.now()
                    # Log verification event
                collection.update_one(
                    {"persisted_faceid": matched_face_id},
                    {"$push": {"verification_logs": {"camera_no": camera_no, "timestamp": current_time}}}
                )
                return {"message": f"Verification successful for {user_info['username']}.","userid":user_info['username']}
            else:
                return {"message": "No user found with the matched face ID."}

        return {"message": "No matching face found in FaceList."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"message": f"An error occurred: {str(e)}"})
    finally:
        if os.path.exists(image_path):
            os.remove(image_path)


# Function to detect face in an image
def detect_face(image_path):
    with open(image_path, 'rb') as image:
        detected_faces = face_client.face.detect_with_stream(image)
        if not detected_faces:
            raise Exception("No face detected in the image")
        return detected_faces[0].face_id

# Function to upload image to Azure Blob Storage
def upload_image_to_blob(image_path):
    blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
    blob_name = f"Dataset/{os.path.basename(image_path)}"
    blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_name)

    with open(image_path, "rb") as data:
        blob_client.upload_blob(data)

    return blob_client.url

# Function to add face to FaceList
def add_face_to_facelist(image_path):
    with open(image_path, 'rb') as image:
        face_list_result = face_client.face_list.add_face_from_stream(FACELIST_ID, image)
        return face_list_result.persisted_face_id

# Function to insert user data into MongoDB
def insert_user_to_db(username, azure_blob_path, persisted_faceid):
    doc = {
        "username": username,
        "azure_blob_path": azure_blob_path,
        "persisted_faceid": persisted_faceid,
        "verification_logs": []
    }
    collection.insert_one(doc)



@app.post("/register_face/")
async def register_face_api(
    username: str = Form(...),
    image: UploadFile = File(...),
):
    image_path = None  # Initialize image_path variable
    try:
        # Check if the username already exists
        existing_user = collection.find_one({"username": username})
        if existing_user:
            # Return a success response with a message instead of an error
            return JSONResponse(status_code=200, content={"success": False, "message": "User already exists."})

        # Save the uploaded image
        image_extension = os.path.splitext(image.filename)[-1]
        image_path = os.path.join(f"{str(uuid.uuid4())}{image_extension}")
        with open(image_path, "wb") as buffer:
            buffer.write(image.file.read())

        # Detect face in the uploaded image
        face_id = detect_face(image_path)

        # Upload image to Blob Storage
        azure_blob_path = upload_image_to_blob(image_path)

        # Register user with application_number
        persisted_face_id = add_face_to_facelist(image_path)
        insert_user_to_db(username, azure_blob_path, persisted_face_id)

        return {"success": True, "message": "Face registered successfully."}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "message": f"An error occurred: {str(e)}"})
    finally:
        if image_path and os.path.exists(image_path):  # Check if image_path is not None and exists
            os.remove(image_path)

@app.post("/proctoring/detect-faces/")
async def detect_faces(image: UploadFile = File(...)):
    try:
        # Read the image data
        image_data = await image.read()

        # Convert the image data to a stream for Azure Face API
        image_stream = io.BytesIO(image_data)

        # Call Azure Face API to detect faces
        detected_faces = face_client.face.detect_with_stream(
            image=image_stream,
            detection_model='detection_03'
        )

        # Open the image using PIL
        image_stream.seek(0)
        image = Image.open(image_stream)
        draw = ImageDraw.Draw(image)

        # Draw bounding boxes around detected faces
        for face in detected_faces:
            rect = face.face_rectangle
            left = rect.left
            top = rect.top
            right = left + rect.width
            bottom = top + rect.height
            draw.rectangle([left, top, right, bottom], outline="red", width=5)

        # Generate a filename for the output image
        output_filename = f"detected_faces_image.jpg"

        # Save the image with bounding boxes to the local directory
        image.save(output_filename, format="JPEG")

        # Return the filename and face count
        face_count = len(detected_faces)
        return {"face_count": face_count, "saved_image": output_filename}

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/")
async def root():
    return {"message": "Welcome to the Face Detection API"}

# # Start the monitoring thread when the app starts
# threading.Thread(target=monitor_window, daemon=True).start()


@app.post("/start_window_monitoring/")
async def start_window_monitoring():
    global monitoring_thread
    if monitoring_thread is None or not monitoring_thread.is_alive():
        monitoring_thread = threading.Thread(target=monitor_window, daemon=True)
        monitoring_thread.start()
        return {"message": "Window monitoring started."}
    else:
        return {"message": "Window monitoring is already running."}

@app.post("/stop_window_monitoring/")
async def stop_window_monitoring():
    global stop_monitoring_flag
    stop_monitoring_flag.set()
    return {"message": "Window monitoring stopped."}


class ExamSubmission(BaseModel):
    username: str
    quiz_id: str
    deviations: list
    fullscreen_exit_count:int
    deviation_count:int
    submission_status:str



@app.post("/submit_exam/")
async def submit_exam(submission: ExamSubmission):
    try:
        # Log the username, quiz_id, and deviations to the server console
        print(f"Username: {submission.username}")
        print(f"Quiz ID: {submission.quiz_id}")
        print("Deviations:")
        print(f"Full Screen count : {submission.fullscreen_exit_count}")
        print(f"Tab switch count: {submission.deviation_count}")
        print(f"Reason for submission: {submission.submission_status}")
        for deviation in submission.deviations:
            print(deviation)

         # Check if a document with the same username and quiz_id already exists
        existing_record = db['User_Deviations'].find_one({
            "username": submission.username,
            "quiz_id": submission.quiz_id
        })

        if existing_record:
            return JSONResponse(content={"message": "Record already exists for this username and quiz ID."})

        # Prepare the document to be inserted into MongoDB
        doc = {
            "username": submission.username,
            "quiz_id": submission.quiz_id,
            "deviations": submission.deviations,
            "fullscreen_exit_count": submission.fullscreen_exit_count,
            "deviation_count": submission.deviation_count,
            "timestamp": datetime.now(),
            "submission_status":submission.submission_status
        }

        # Insert the document into the User_Deviations collection
        collection_user_deviations = db['User_Deviations']
        collection_user_deviations.insert_one(doc)

        return JSONResponse(content={"message": "Exam submitted successfully!"})
    except Exception as e:
        return JSONResponse(status_code=500, content={"message": f"An error occurred: {str(e)}"})




if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
