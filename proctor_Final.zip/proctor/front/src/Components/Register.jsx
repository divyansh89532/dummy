import React, { useRef, useState, useEffect } from "react";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import img2 from '../assets/register_BG.jpg';
import { useNavigate } from "react-router-dom";

const Register = () => {
  const videoRef = useRef(null);
  const [results, setResults] = useState(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [username, setUsername] = useState("");
  const [applicationNumber, setApplicationNumber] = useState("");
  const [validity, setValidity] = useState("");


  const navigate = useNavigate();

  useEffect(() => {
    navigator.mediaDevices
      .getUserMedia({ video: true })
      .then((stream) => {
        videoRef.current.srcObject = stream;
      })
      .catch((err) => {
        console.error("Error accessing camera: ", err);
      });

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const captureFrame = async () => {
    const video = videoRef.current;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext("2d");
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    const image = canvas.toDataURL("image/jpeg");

    try {
      const formData = new FormData();
      const username = "Test 2"
      formData.append("username", username);
      formData.append("image", dataURLtoBlob(image));

      const response = await axios.post("http://localhost:8000/register_face/", formData);
      setResults(response.data.message);
      setIsRegistered(true);

      // console.log("response -> ", response.data.message);

      if (response.data.message.includes("Face registered successfully.")) {
        toast.success("Registration successful!", {
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
      }
      else if (response.data.message.includes("User already exists.")) {
        toast.warn("You are already registered! Navigating to exam section", {
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
        setTimeout(() => {
          navigate('/test', { state: { username } });
        }, 3000)

      } 
      else {
        toast.error("Registration failed. Please try again.", {
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
      }
    } catch (error) {
      console.error("Registration error: ", error);
      toast.error("An error occurred during registration. Please try again.", {
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };

  const dataURLtoBlob = (dataurl) => {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], { type: mime });
  };

  const handleTryAgain = () => {
    setIsRegistered(false);
    setResults(null);
    navigate('/register');
  };

  const handleRedirect = () => {
    navigate('/');
  }

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-4xl flex relative">
        <button
          onClick={handleRedirect}
          className="absolute top-2 right-2 text-red-500 text-2xl font-bold hover:text-red-700"
          aria-label="Close"
        >
          &times;
        </button>
        <div className="w-full sm:w-1/2 p-4 border-r border-gray-200">
          <h1 className="text-2xl font-bold mb-4 text-center text-blue-500">Candidate Face Registration</h1>
          {!isRegistered ? (
            <>
              {/* <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-2 mb-2 border rounded shadow focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300"
              /> */}
              <div className="mb-4 flex justify-center">
                <video ref={videoRef} autoPlay className="w-full h-auto rounded-md border border-gray-300" />
              </div>
              <div className="flex justify-center">
                <button onClick={captureFrame} className="bg-blue-500 text-white font-bold py-2 px-4 rounded shadow hover:bg-blue-700 transition duration-300">
                  Capture and Register
                </button>
              </div>
            </>
          ) : (
            <div className="text-center">
              <h2 className="text-xl font-semibold mb-2">Registration Results:</h2>
              <p className="mb-4">{results}</p>
              {!results.includes("Registration successful") || results.includes("User already exists.")&& (
                <button onClick={handleTryAgain} className="bg-yellow-500 text-white font-bold py-2 px-4 rounded shadow hover:bg-yellow-600 transition duration-300">
                  Try Again
                </button>
              )}
            </div>
          )}
        </div>
        <div className="w-full sm:w-1/2 p-4">
          <h2 className="text-xl font-semibold mb-4">Instructions</h2>
          <ul className="list-disc list-inside mb-4">
            <li>Ensure a stable and fast internet connection to avoid disruptions.</li>
            <li>Make sure your webcam and microphone are functioning correctly.</li>
            <li>Disable automatic updates during the registration process.</li>
            <li>Turn off pop-up blockers that might interfere with the registration.</li>
          </ul>
          <img src={img2} alt="Background" className="w-full h-auto rounded-md mt-6"/>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
};

export default Register;
