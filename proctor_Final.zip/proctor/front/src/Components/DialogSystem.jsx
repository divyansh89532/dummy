import React, { useRef, useState, useEffect } from "react";
import axios from "axios";
import img1 from "../assets/bgg_proct2.png";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
 
const DialogSystem = ({ isOpen, onClose }) => {
  const videoRef = useRef(null);
  const [userid, setUserid] = useState(null);  
  const [results, setResults] = useState(null);
  const [isVerified, setIsVerified] = useState(false);
  const [cameraPermissionGranted, setCameraPermissionGranted] = useState(false);
  const navigate = useNavigate();
 
  useEffect(() => {
    const requestCameraPermissions = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        setCameraPermissionGranted(true);
        videoRef.current.srcObject = stream;
      } catch (err) {
        setCameraPermissionGranted(false);
        console.error("Error accessing camera: ", err);
      }
    };
 
    if (isOpen) {
      requestCameraPermissions();
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    }
 
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    };
  }, [isOpen]);
 
  const captureFrame = async () => {
    if (!cameraPermissionGranted) {
      toast.error("Please grant camera permissions before verification.", {
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
      return;
    }
 
    const video = videoRef.current;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext("2d");
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
 
    const image = canvas.toDataURL("image/jpeg");
 
    try {
      const formData = new FormData();
      formData.append("image", dataURLtoBlob(image));
      formData.append("camera_no", 1);
 
      const response = await axios.post("http://localhost:8000/verify_face/", formData);
      setResults(response.data.message);
      setUserid(response.data.userid);  
      setIsVerified(true);
 
      if (response.data.message.includes("Verification successful")) {
        toast.success("Verification successful! Redirecting to the test page...", {
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
 
        setTimeout(() => {
          navigate("/test",{ state: { userid: response.data.userid } });
        }, 3000);
      } else {
        toast.error("Verification failed. Redirecting to the registration page...", {
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
 
        setTimeout(() => {
          navigate("/register");
        }, 3000);
      }
    } catch (error) {
      console.error("Verification error: ", error);
      toast.error("An error occurred during verification. Please try again.", {
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };
 
  const dataURLtoBlob = (dataurl) => {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], { type: mime });
  };
 
  const handleTryAgain = () => {
    setIsVerified(false);
    setResults(null);
    navigate('/register');
  };
 
  if (!isOpen) return null;
 
  const handleClose = () => {
    onClose();
  };
 
  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-4xl flex relative">
        <div className="w-full sm:w-1/2 p-4 border-r border-gray-200">
          <h1 className="text-2xl font-bold mb-4 text-center">System Compatibility Check</h1>
          {!isVerified ? (
            <>
              <div className="mb-4 flex justify-center">
                <video ref={videoRef} autoPlay className="w-full h-auto rounded-md border border-gray-300" />
              </div>
              <div className="flex justify-center">
                <button onClick={captureFrame} className="bg-blue-500 text-white font-bold py-2 px-4 rounded shadow hover:bg-blue-700 transition duration-300">
                  Capture and Verify
                </button>
              </div>
            </>
          ) : (
            <div className="text-center">
              <h2 className="text-xl font-semibold mb-2">Verification Results:</h2>
              <p className="mb-4">{results}</p>
              {!results.includes("Verification successful") && (
                <button onClick={handleTryAgain} className="bg-yellow-500 text-white font-bold py-2 px-4 rounded shadow hover:bg-yellow-600 transition duration-300">
                  Try Again
                </button>
              )}
            </div>
          )}
        </div>
        <div className="w-full sm:w-1/2 p-4 relative">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url(${img1})`,
              zIndex: -1,
            }}
          />
          <h2 className="text-xl font-semibold mb-4">Instructions</h2>
          <ul className="list-disc list-inside mb-4">
            <li>Verify that you have a stable and fast internet connection to prevent disruptions.</li>
            <li>Confirm that your webcam and microphone are functional and accessible by the exam software.</li>
            <li>Disable automatic updates during the exam to avoid unexpected reboots or interruptions.</li>
            <li>Disable any pop-up blockers that might interfere with exam prompts or notifications.</li>
            <li>Do not switch tabs or exit full screen as this might lead to exam termination.</li>
          </ul>
          <br />
          <div className="flex flex-col mt-6">
            <p className="mb-2 text-gray-700">Not registered?</p>
            <button
              onClick={() => navigate("/register")}
              className="bg-green-500 text-white font-bold py-2 px-4 rounded shadow hover:bg-green-600 transition duration-300"
            >
              Candidate Face Registration
            </button>
          </div>
        </div>
        <div className="absolute top-1 right-1 m-2">
        <button
            onClick={handleClose}
            className="text-red-600 font-bold py-2 px-4 rounded hover:bg-white transition duration-300"
          >
            X
          </button>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
};
 
export default DialogSystem;
 
 