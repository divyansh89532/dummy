import React, { useState, useEffect } from 'react';
import { useNavigate,useLocation } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const PermissionsCheck = ({ setIsExamActive, setIsFullscreen }) => {
  const [micPermission, setMicPermission] = useState(null);
  const [cameraPermission, setCameraPermission] = useState(null);
  const [canProceed, setCanProceed] = useState(false);
  const location = useLocation();
  const username  = location.state.userid;
  const navigate = useNavigate();

  const showPermissionToast = (message) => {
    toast.error(message, {
      toastId: 'permission-toast',
      autoClose: 10000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
    });
  };

  const checkPermissions = async () => {
    try {
      const micPermissionStatus = await navigator.permissions.query({ name: 'microphone' });
      const cameraPermissionStatus = await navigator.permissions.query({ name: 'camera' });

      setMicPermission(micPermissionStatus.state === 'granted');
      setCameraPermission(cameraPermissionStatus.state === 'granted');

      if (micPermissionStatus.state !== 'granted') {
        showPermissionToast('Microphone access is required for taking this exam.');
      }

      if (cameraPermissionStatus.state !== 'granted') {
        showPermissionToast('Camera access is required for taking this exam.');
      }

      setCanProceed(micPermissionStatus.state === 'granted' && cameraPermissionStatus.state === 'granted');
    } catch (error) {
      console.error('Error checking permissions:', error);
      toast.error('An error occurred while checking permissions.', {
        toastId: 'permission-toast',
        autoClose: 10000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };

  useEffect(() => {
    checkPermissions();
  }, []);

  const handleStartClick = async () => {
    if (canProceed) {
      try {
        const response = await fetch('http://localhost:8000/start_window_monitoring/', {
          method: 'POST',
        });
        const data = await response.json();
        console.log(data.message);

        if (document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen()
            .then(() => {
              setIsFullscreen(true);
              setIsExamActive(true);
              navigate('/proctoring',{ state: { userid: username } });
            })
            .catch(err => console.error("Error attempting to enable full-screen mode:", err));
        } else {
          setIsExamActive(true);
          setIsFullscreen(true);
          navigate('/proctoring');
        }
      } catch (error) {
        console.error('Error starting window monitoring:', error);
        toast.error('An error occurred while starting window monitoring.', {
          toastId: 'start-monitor-toast',
          autoClose: 10000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
      }
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-md mx-auto" style={{ minHeight: '300px' }}>
        <h1 className="text-2xl font-bold text-gray-800 mb-4 text-center">Checking Configuration...</h1>
        <br/>
        <div className="text-center space-y-4">
          <div className={`flex items-center justify-center space-x-3 ${micPermission ? 'text-green-600' : 'text-red-600'}`}>
            <span className="text-2xl">{micPermission ? '✅' : '❌'}</span>
            <span className="text-lg font-medium">Microphone Access: {micPermission ? 'Granted' : 'Denied'}</span>
          </div>

          <div className={`flex items-center justify-center space-x-3 ${cameraPermission ? 'text-green-600' : 'text-red-600'}`}>
            <span className="text-2xl">{cameraPermission ? '✅' : '❌'}</span>
            <span className="text-lg font-medium">Camera Access: {cameraPermission ? 'Granted' : 'Denied'}</span>
          </div>
        </div>

        <button
          onClick={handleStartClick}
          disabled={!canProceed}
          className={`mt-6 bg-blue-500 text-white font-semibold py-2 px-4 rounded shadow-md w-full ${canProceed ? 'hover:bg-blue-600' : 'opacity-50 cursor-not-allowed'}`}
          title={!canProceed ? 'First give all the permissions to start the test' : ''}
        >
          Start Exam
        </button>
      </div>

      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
};

export default PermissionsCheck;
