import React from "react";

const DeviceWarning = ({ cautionImage }) => {
  return (
    <div style={styles.container}>
      {cautionImage && <img src={cautionImage} alt="Caution" style={styles.image} />}
      <h1 style={styles.text}>You need to be on a laptop or a larger screen.</h1>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    flexDirection: "column", 
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    color: "#721c24",
    fontFamily: "Arial, sans-serif",
    padding: "0 20px", 
    textAlign: "center", 
  },
  image: {
    width: "150px", 
    marginBottom: "20px", 
  },
  text: {
    textAlign: "center", 
    fontSize: "2.5rem",   
  },
};

export default DeviceWarning;
