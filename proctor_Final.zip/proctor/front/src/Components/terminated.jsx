import React, { useEffect } from 'react';

export default function TestTerminated() {
  useEffect(() => {
    // Get all media devices and stop them
    navigator.mediaDevices.enumerateDevices().then(devices => {
      devices.forEach(device => {
        if (device.kind === 'videoinput' || device.kind === 'audioinput') {
          navigator.mediaDevices.getUserMedia({ 
            audio: device.kind === 'audioinput', 
            video: device.kind === 'videoinput' 
          }).then(stream => {
            stream.getTracks().forEach(track => {
              track.stop(); // Stop each track
            });
          }).catch(err => console.error('Error accessing media devices:', err));
        }
      });
    });
  }, []);

  return (
    <div>
      <h1 className='text-center'>
      Test Submitted
      </h1>
    </div>
  );
}
