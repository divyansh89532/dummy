import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ProctoringWithWindowWatcher from './Components/ProctoringSystem'
import PermissionsCheck from './Components/PermissionCheck'
import TestTerminated from './Components/terminated'
import ButtonAttend from './Components/ButtonAttend';
import { useState } from 'react';
import Register from './Components/Register';
import { useMediaQuery } from 'react-responsive';
import DeviceWarning from './Components/DeviceWarning';
import cautionImageUrl from "./assets/caution.jpg";

function App() {

  const [isFullscreen , setIsFullscreen] = useState(false);
  const [isExamActive , setIsExamActive] = useState(false);
  // Detects handheld devices (smartphones, tablets, etc.)
  const isMobile = useMediaQuery({
    query: '(max-width: 1024px), (hover: none) and (pointer: coarse)'
  });

  // Detects non-handheld devices (laptops, desktops, etc.)
  const isBrowser = useMediaQuery({
    query: '(min-width: 1025px), (hover: hover) and (pointer: fine)'
  });

  return (
    <>
      {isBrowser && (
          <div>
            <Router>
              <Routes>
                <Route path="/test" element={<PermissionsCheck setIsExamActive = {setIsExamActive} setIsFullscreen = {setIsFullscreen}/>} />
                <Route path="/proctoring" element={<ProctoringWithWindowWatcher isExamActive = {isExamActive} isFullscreen = {isFullscreen} setIsExamActive = {setIsExamActive} setIsFullscreen = {setIsFullscreen}/>} />
                <Route path='/' element={<ButtonAttend/>}></Route>
                <Route path='/terminated' element={<TestTerminated/>}></Route>
                <Route path='/register' element={<Register/>}></Route>
              </Routes>
          </Router>
          </div>
      )}
      {isMobile && (
        <>
          <DeviceWarning cautionImage={cautionImageUrl}/>
        </>
      )}
    </>
  )
}

export default App
