import React, { useState, useEffect, useRef } from 'react';
import * as sdk from 'microsoft-cognitiveservices-speech-sdk';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from "react-router-dom"; 

const SPEECH_KEY = import.meta.env.VITE_SPEECH_KEY;
const SPEECH_REGION = import.meta.env.VITE_SPEECH_REGION;

function ProctoringWithWindowWatcher({setIsExamActive , setIsFullscreen , isExamActive, isFullscreen}) {
  const [isListening, setIsListening] = useState(false);
  const [noiseCount, setNoiseCount] = useState(0);
  const [lastToastTime, setLastToastTime] = useState(0);
  const [faceCount, setFaceCount] = useState(null);
  const [alertMessage, setAlertMessage] = useState('');
  const [exitCount, setExitCount] = useState(0);
  const [deviationCount, setDeviationCount] = useState(0);
  const [initialTitle, setInitialTitle] = useState('');
  const [currentTitle, setCurrentTitle] = useState('');
  const [deviations, setDeviations] = useState([]);
  // const [isFullscreen, setIsFullscreen] = useState(false); // Track fullscreen state using useState
  // const [isExamActive, setIsExamActive] = useState(true); // Track if the exam is active

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const speechConfig = useRef(null);
  const audioConfig = useRef(null);
  const recognizer = useRef(null);

  
  // Function to enter fullscreen mode
  const enterFullscreen = () => {
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen()
        .then(() => {
          setIsFullscreen(true);
          setIsExamActive(true); // Activate the exam when entering fullscreen
        })
        .catch(err => console.error("Error attempting to enable full-screen mode:", err));
    }
  };

  const submitExam = async () => {
    const response = await fetch('http://localhost:8000/stop_window_monitoring/', {
      method: 'POST',
    });
    const data = await response.json();
    console.log(data.message); // Optional: log the response message
    
    
  };

  // Function to handle fullscreen exit
  const handleFullscreenExit = () => {
    setIsFullscreen(false);
    setExitCount(prevCount => prevCount + 1);
    setIsExamActive(false); // Deactivate the exam when exiting fullscreen
    toast.warn('Fullscreen exited! Click the button below to resume the exam.');
  };

  useEffect(() => {
    // Initialize Speech Recognizer
    speechConfig.current = sdk.SpeechConfig.fromSubscription(
      SPEECH_KEY,
      SPEECH_REGION
    );
    speechConfig.current.speechRecognitionLanguage = 'en-US';

    audioConfig.current = sdk.AudioConfig.fromDefaultMicrophoneInput();
    recognizer.current = new sdk.SpeechRecognizer(
      speechConfig.current,
      audioConfig.current
    );

    const processRecognizingTranscript = (event) => {
      const result = event.result;
      const now = Date.now();

      if (result.reason === sdk.ResultReason.RecognizingSpeech) {
        if (now - lastToastTime >= 15000) {  // Check if 15 seconds have passed since the last toast
          toast.error('Noise detected', {
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
          });
          setNoiseCount((prevCount) => prevCount + 1);
          setLastToastTime(now);
        }
      }
    };

    recognizer.current.recognizing = (s, e) => processRecognizingTranscript(e);

    recognizer.current.startContinuousRecognitionAsync(() => {
      console.log('Speech recognition started.');
      setIsListening(true);
    });

    // Access the user's camera
    navigator.mediaDevices.getUserMedia({ video: true })
      .then((stream) => {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      })
      .catch((err) => {
        console.error('Error accessing camera:', err);
        toast.error('Camera access is required for taking this exam');
      });

    // Set an interval to capture images every 30 seconds
    const interval = setInterval(() => {
      captureAndCheckImage();
    }, 30000);

    return () => {
      recognizer.current.stopContinuousRecognitionAsync(() => {
        setIsListening(false);
      });
      clearInterval(interval); // Cleanup on unmount
    };
  }, [lastToastTime]);

  const captureAndCheckImage = async () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(async (blob) => {
      const formData = new FormData();
      formData.append('image', blob, 'snapshot.jpg');

      try {
        const response = await fetch('http://localhost:8000/proctoring/detect-faces', {
          method: 'POST',
          body: formData,
        });

        const data = await response.json();
        setFaceCount(data.face_count);

        let message = '';
        if (data.face_count > 1) {
          message = 'Multiple faces detected!';
          toast.error(message, {
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
          });
        } else if (data.face_count < 1) {
          message = 'No face detected!';
          toast.error(message, {
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
          });
        } else {
          message = 'Single face detected. Examination environment is secure.';
        }

        setAlertMessage(message);

      } catch (error) {
        console.error('Error:', error);
        setAlertMessage('An error occurred while processing the image.');
      }
    }, 'image/jpeg');
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      axios.get('http://localhost:8000/window_status')
        .then(response => {
          const data = response.data;
          setInitialTitle(data.initial_window_title);
          setCurrentTitle(data.current_window_title);
          setDeviationCount(data.deviation_count);
          setDeviations(data.deviations);

          // Check if the window title has changed
          if (data.deviation_count > deviationCount) {
            toast.warn('Tab switched!'); // Show warning toast
          }
        })
        .catch(error => {
          console.error("There was an error fetching the window status!", error);
        });
    }, 1000);

    return () => clearInterval(intervalId);
  }, [deviationCount]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      if (document.fullscreenElement) {
        // Entering fullscreen mode
        if (!isFullscreen) {
          setIsFullscreen(true);
          setIsExamActive(true); // Activate the exam when entering fullscreen
        }
      } else {
        // Exiting fullscreen mode
        if (isFullscreen) {
          handleFullscreenExit();
        }
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [isFullscreen]); // Dependency on isFullscreen to re-run the effect when it changes

  return (
    <div className="flex flex-col items-center p-6 space-y-4">
      <h1 className="text-2xl font-bold text-gray-800">Exam Proctoring System</h1>

      {isFullscreen && (
        <div style={{ color: 'green' }}>
          <h2>Fullscreen Mode Active</h2>
        </div>
      )}

      {!isFullscreen && !isExamActive && (
        <button 
          className="bg-green-500 text-white px-4 py-2 rounded"
          onClick={enterFullscreen}
        >
          Resume Exam
        </button>
      )}

      {isFullscreen && (
        <button 
          className="bg-green-500 text-white px-4 py-2 rounded"
          onClick={submitExam}
        >
          Submit Exam
        </button>
      )}

      <video
        ref={videoRef}
        className="fixed bottom-10 left-10 w-36 h-auto z-50 rounded-lg shadow-lg"
      />
      <canvas ref={canvasRef} className="hidden" />

      {faceCount !== null && (
        <div className="text-center">
          <p className="text-lg font-medium text-gray-700">
            {alertMessage}
          </p>
        </div>
      )}

      <p><strong>Initial Window Title:</strong> {initialTitle}</p>
      <p><strong>Current Window Title:</strong> {currentTitle}</p>
      <p><strong>Deviation Count:</strong> {deviationCount}</p>
      <p><strong>Fullscreen Exit Count:</strong> {exitCount}</p>

      <h2>Deviations:</h2>
      <ul>
        {deviations.map((title, index) => (
          <li key={index}>{title}</li>
        ))}
      </ul>

      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
}

export default ProctoringWithWindowWatcher;
