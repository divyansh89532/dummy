import React from 'react'

function QuizButton() {
  return (
    <div>QuizButton</div>
  )
}

export default QuizButton